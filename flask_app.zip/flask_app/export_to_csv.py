import csv
from pymongo import MongoClient

# Connect to MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client["survey_db"]
responses = db["responses"]

# CSV file name
csv_file = "survey_responses.csv"

# Define CSV column headers
fieldnames = [
    "age",
    "gender",
    "total_income",
    "utilities",
    "entertainment",
    "school_fees",
    "shopping",
    "healthcare",
    "total_expenses",
    "savings",
    "created_at"
]

with open(csv_file, mode="w", newline="", encoding="utf-8") as file:
    writer = csv.DictWriter(file, fieldnames=fieldnames)
    writer.writeheader()

    #  Loop through MongoDB documents
    for doc in responses.find():
        row = {
            "age": doc.get("age"),
            "gender": doc.get("gender"),
            "total_income": doc.get("total_income"),
            "utilities": doc.get("expenses", {}).get("utilities", 0),
            "entertainment": doc.get("expenses", {}).get("entertainment", 0),
            "school_fees": doc.get("expenses", {}).get("school_fees", 0),
            "shopping": doc.get("expenses", {}).get("shopping", 0),
            "healthcare": doc.get("expenses", {}).get("healthcare", 0),
            "total_expenses": doc.get("total_expenses"),
            "savings": doc.get("savings"),
            "created_at": doc.get("created_at")
        }

        writer.writerow(row)

print(" Data exported successfully to survey_responses.csv")