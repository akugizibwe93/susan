from flask_wtf import FlaskForm
from wtforms import (StringField, TextAreaField, IntegerField, DecimalField, BooleanField, RadioField,
                     SelectMultipleField, SubmitField)
from wtforms.validators import InputRequired, Length, Optional, NumberRange
from wtforms.widgets import CheckboxInput, ListWidget

class CourseForm(FlaskForm):
    age = RadioField ('How old are you?',
                      choices = ['18 - 25','26 - 35','36 - 45', '> 45','prefer not to say'])
    gender = RadioField ('By what gender do you identify?',
                        choices = ['Female','Male', 'Prefer not to say'], validators=[InputRequired()])
    Income = IntegerField ('What is your total income?', validators=[InputRequired()])
    
    utilities = BooleanField("Utilities")
    utilities_amount = DecimalField(
        "Amount",
        validators=[Optional()]
    )

    entertainment = BooleanField("Entertainment")
    entertainment_amount = DecimalField(
        "Amount",
        validators=[Optional(), NumberRange(min=100)]
    )

    school_fees = BooleanField("School Fees")
    school_fees_amount = DecimalField(
        "Amount",
        validators=[Optional(), NumberRange(min=0)]
    )

    shopping = BooleanField("Shopping")
    shopping_amount = DecimalField(
        "Amount",
        validators=[Optional(), NumberRange(min=0)]
    )

    healthcare = BooleanField("Healthcare")
    healthcare_amount = DecimalField(
        "Amount",
        validators=[Optional(), NumberRange(min=0)]
    )
   
    submit = SubmitField("Submit")

