from datetime import datetime


class User:
    def __init__(self, age, gender, total_income, expenses):
        """
        Initialize a User object.

        :param age: Age group (string)
        :param gender: Gender (string)
        :param total_income: Total income (float)
        :param expenses: Dictionary of expense categories and amounts
        """
        self.age = age
        self.gender = gender
        self.total_income = float(total_income)
        self.expenses = self._clean_expenses(expenses)
        self.created_at = datetime.utcnow()

    def _clean_expenses(self, expenses):
        """
        Remove empty or zero expenses and ensure values are floats.
        """
        clean = {}
        for category, amount in expenses.items():
            if amount is not None and amount > 0:
                clean[category] = float(amount)
        return clean

    def total_expenses(self):
        """
        Calculate total expenses.
        """
        return sum(self.expenses.values())

    def savings(self):
        """
        Calculate remaining income after expenses.
        """
        return self.total_income - self.total_expenses()

    def to_dict(self):
        """
        Convert user data into a MongoDB‑ready dictionary.
        """
        return {
            "age": self.age,
            "gender": self.gender,
            "total_income": self.total_income,
            "expenses": self.expenses,
            "total_expenses": self.total_expenses(),
            "savings": self.savings(),
            "created_at": self.created_at
        }