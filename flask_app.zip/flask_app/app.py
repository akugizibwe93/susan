from flask import Flask, render_template, redirect, url_for
from forms import CourseForm
from pymongo import MongoClient
from datetime import datetime
from models.user import User

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your secret key'



client = MongoClient("mongodb://localhost:27017/")
db = client["survey_db"]
responses = db["responses"]


@app.route('/', methods=('GET', 'POST'))
def index():
    
    form = CourseForm()

    if form.validate_on_submit():
       
       expenses = {}

       if form.utilities.data:
            expenses["utilities"] = form.utilities_amount.data
       if form.entertainment.data:
            expenses["entertainment"] = form.entertainment_amount.data
       if form.school_fees.data:
            expenses["school_fees"] = form.school_fees_amount.data
       if form.shopping.data:
            expenses["shopping"] = form.shopping_amount.data
       if form.healthcare.data:
            expenses["healthcare"] = form.healthcare_amount.data

       user = User(
            age=form.age.data,
            gender=form.gender.data,
            total_income=form.Income.data,
            expenses=expenses 
        )
       responses.insert_one(user.to_dict())



        # ✅ Insert into MongoDB

       responses.insert_one(user.to_dict())


       return "Data captured!"


    return render_template('index.html',form = form
                          ) 
